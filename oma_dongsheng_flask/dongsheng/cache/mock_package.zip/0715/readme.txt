
SearchLauncherQuickStep.apk
这个apk是用来验证bug 675486的； 验证前安装，并重启手机；
bug 675486 - 【VZW FOTA】【EVT_V008】【VZ_TC_MMLTEOTADM_7616】When alarm clock notification pops up, install notification did not go into background
临时方案，后面会出新刷机包，包含这个apk;
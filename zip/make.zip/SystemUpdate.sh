#!/bin/bash

ROOTPATH="target_files-package"
mkdir -p $ROOTPATH
#build
mkdir -p  $ROOTPATH/build/target/product/
cp -a build/target/product/security/  $ROOTPATH/build/target/product/
mkdir -p $ROOTPATH/build/tools/
cp -ar build/tools/releasetools/  $ROOTPATH/build/tools/

#mkdir -p $ROOTPATH/$1/
mkdir -p $ROOTPATH/out/host/linux-x86/bin/
cp -a out/host/linux-x86/bin/minigzip  out/host/linux-x86/bin/mkbootfs out/host/linux-x86/bin/mkbootimg out/host/linux-x86/bin/fs_config out/host/linux-x86/bin/zipalign  out/host/linux-x86/bin/bsdiff out/host/linux-x86/bin/imgdiff out/host/linux-x86/bin/mkuserimg.sh  out/host/linux-x86/bin/make_ext4fs  out/host/linux-x86/bin/aapt  out/host/linux-x86/bin/simg2img out/host/linux-x86/bin/e2fsck $ROOTPATH/out/host/linux-x86/bin/
cp -a  out/host/linux-x86/bin/aapt $ROOTPATH/out/host/linux-x86/bin/

cp -ar out/host/linux-x86/bin/lib/ $ROOTPATH/out/host/linux-x86/bin/
mkdir -p $ROOTPATH/out/host/linux-x86/framework
cp -a out/host/linux-x86/framework/signapk.jar  out/host/linux-x86/framework/dumpkey.jar $ROOTPATH/out/host/linux-x86/framework/
mkdir -p $ROOTPATH/$4/
cp -a $4/libc++$5 \
$4/liblog$5 \
$4/libcutils$5 \
$4/libselinux$5 \
$4/libcrypto-host$5 \
$4/libext2fs-host$5 \
$4/libext2_blkid-host$5 \
$4/libext2_com_err-host$5 \
$4/libext2_e2p-host$5 \
$4/libext2_misc$5 \
$4/libext2_profile-host$5 \
$4/libext2_quota-host$5 \
$4/libext2_uuid-host$5 \
$4/libconscrypt_openjdk_jni$5 \
$4/libbrillo$5 \
$4/libbrillo-stream$5 \
$4/libchrome$5 \
$4/libcurl-host$5 \
$4/libevent-host$5 \
$4/libprotobuf-cpp-lite$5 \
$4/libssl-host$5 \
$4/libz-host$5 \
$4/libsparse-host$5 \
$4/libbase$5 \
$4/libpcre2$5 \
$4/libbrotli$5 \
$4/libfec$5 \
$4/libziparchive$5 \
$4/libcrypto_utils$5 \
$4/libext4_utils$5 \
$4/libsquashfs_utils$5 \
$ROOTPATH/$4/
#system
mkdir -p $ROOTPATH/system/extras/verity/
cp -a system/extras/verity/build_verity_metadata.py $ROOTPATH/system/extras/verity/

#device
mkdir -p $ROOTPATH/device/rockchip/common/
cp -a device/rockchip/common/releasetools.py $ROOTPATH/device/rockchip/common/

#new target_files
mkdir -p $ROOTPATH/out/target/product/$3/root/
cp -a $1/obj/PACKAGING/systemimage_intermediates/system_image_info.txt $ROOTPATH/
cp -a device/rockchip/common/sepolicy/file_contexts  $ROOTPATH/out/target/product/$3/root/
#target_files

echo `ls -lrt $1/obj/PACKAGING/target_files_intermediates/*target_files*.zip|tail -n 1|awk '{print $NF}'`
cp -a `ls -lrt $1/obj/PACKAGING/target_files_intermediates/*target_files*.zip|tail -n 1|awk '{print $NF}'`  $ROOTPATH/ota_target_files.zip

#build.prop
cp -a $1/system/build.prop $ROOTPATH/build.prop

if [ -f $1/system/build.prop ]; then
OtaVersion=$(grep "ro.build.display.id=" "$1/system/build.prop"|awk -F "=" '{print $NF}' )
echo "OtaVersion = $OtaVersion"
fi

if [ -f $1/target_files-package.zip ]; then
echo "delete exist file:$1/target_files-package"
rm -f $1/target_files-package.zip
fi

cd target_files-package
zip -rq target_files-package.zip build device out system build.prop ota_target_files.zip system_image_info.txt
cd ..
mv target_files-package/target_files-package.zip $1/$OtaVersion.zip
rm -rf target_files-package



#!/bin/bash

echo ""
echo "# begin systemupdate"
#type info: phone, pad ,box, tv
echo "ro.update.type=pad"
#model info, Settings->About phone->Model number
if [ -n "`grep "ro.product.model=" $1`" ] ; then
FotaDevice=$(grep "ro.product.model=" "$1"|awk -F "=" '{print $NF}' )
elif [ -n "`grep "ro.product.system.model=" $1`" ] ; then
FotaDevice=$(grep "ro.product.system.model=" "$1"|awk -F "=" '{print $NF}' )
elif [ -n "`grep "ro.product.system.device=" $1`" ] ; then
FotaDevice=$(grep "ro.product.system.device=" "$1"|awk -F "=" '{print $NF}' )
else
echo "ERROR: model do not exist in system/build.prop"
exit 0
fi
echo "ro.update.device=$FotaDevice"
#version number, Settings->About phone->Build number
FotaVersion=$(grep "ro.build.display.id=" "$1"|awk -F "=" '{print $NF}' )`date +_%Y%m%d-%H%M`
echo "ro.update.version=$FotaVersion"
echo "# end systemupdate"
